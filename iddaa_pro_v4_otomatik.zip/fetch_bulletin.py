import os, json, math, datetime, requests

API_KEY = os.environ["FOOTBALLDATA_API_KEY"]
BASE = "https://footballdata.io/api/v1"
HEADERS = {"Authorization": f"Bearer {API_KEY}"}

def get(path, params=None):
    r = requests.get(BASE + path, headers=HEADERS, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def poisson(k, lam):
    return math.exp(-lam) * lam**k / math.factorial(k)

def probs(hxg, axg):
    z = [[poisson(i,hxg)*poisson(j,axg) for j in range(9)] for i in range(9)]
    s = sum(map(sum,z))
    h=d=a=o25=btts=0
    for i in range(9):
        for j in range(9):
            p=z[i][j]/s
            if i>j: h += p
            elif i==j: d += p
            else: a += p
            if i+j>2: o25 += p
            if i>0 and j>0: btts += p
    return h,d,a,o25,btts

def grade(score):
    if score >= 78: return "A+"
    if score >= 66: return "A"
    if score >= 54: return "B"
    if score >= 42: return "C"
    return "N"

def num(x, default=0):
    try: return float(x)
    except: return default

def main():
    data = get("/fixtures/upcoming")
    fixtures = data.get("data", data if isinstance(data,list) else [])
    matches=[]
    for f in fixtures:
        try:
            home=((f.get("home_team") or f.get("home") or {}).get("name") if isinstance(f.get("home_team") or f.get("home"),dict) else f.get("home_team"))
            away=((f.get("away_team") or f.get("away") or {}).get("name") if isinstance(f.get("away_team") or f.get("away"),dict) else f.get("away_team"))
            mid=f.get("id") or f.get("match_id")
            if not home or not away or not mid: continue

            odds={}
            try:
                od=get(f"/matches/{mid}/odds")
                od=od.get("data",od)
                # Flexible extraction for common API response shapes.
                for item in (od if isinstance(od,list) else od.get("markets",[]) if isinstance(od,dict) else []):
                    market=str(item.get("market","")).lower()
                    vals=item.get("outcomes") or item.get("odds") or {}
                    if market in ("match_winner","1x2"):
                        odds["MS1"]=num(vals.get("home") if isinstance(vals,dict) else None)
                        odds["X"]=num(vals.get("draw") if isinstance(vals,dict) else None)
                        odds["MS2"]=num(vals.get("away") if isinstance(vals,dict) else None)
            except Exception:
                pass

            # Prefer provider probabilities/stats when available; fallback to neutral xG priors.
            hxg,axg = 1.35,1.10
            corners = 9.0
            try:
                st=get(f"/matches/{mid}/stats")
                sd=st.get("data",st)
                hxg=num(sd.get("home_xg") or sd.get("homeXg"),hxg)
                axg=num(sd.get("away_xg") or sd.get("awayXg"),axg)
                corners=num(sd.get("home_corners"),4.5)+num(sd.get("away_corners"),4.5)
            except Exception:
                pass

            h,d,a,o25,btts=probs(hxg,axg)
            p=[h,d,a]; pick=["MS1","X","MS2"][p.index(max(p))]
            bestodd=odds.get(pick,0)
            value=(max(p)*bestodd-1) if bestodd>1 else 0
            market_agree=0
            if all(odds.get(k,0)>1 for k in ("MS1","X","MS2")):
                s=sum(1/odds[k] for k in ("MS1","X","MS2"))
                market=[(1/odds[k])/s for k in ("MS1","X","MS2")]
                market_agree=max(0,1-abs(max(p)-max(market))*2)
            else:
                market_agree=.5
            score=min(100, max(0, max(p)*45 + max(value,0)*70 + market_agree*20))
            matches.append({"HomeTeam":home,"AwayTeam":away,"MS1":h,"X":d,"MS2":a,"Over25":o25,"BTTS":btts,"ExpGoals":hxg+axg,"ExpCorners":corners,"Pick":pick,"Value":value,"Score":score,"Grade":grade(score)})
        except Exception:
            continue

    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    out={"meta":{"updated_at":now,"source":"Footballdata.io","count":len(matches)},"matches":matches}
    with open("data.json","w",encoding="utf-8") as f: json.dump(out,f,ensure_ascii=False,indent=2)
    print(f"Wrote {len(matches)} matches")

if __name__=="__main__":
    main()
