# İddaa Pro V4

Bu sürüm GitHub Pages + GitHub Actions kullanır.

## 1) API anahtarı
Footballdata.io üzerinden API anahtarı alın:
https://footballdata.io/signup

## 2) GitHub Secret
Repo → Settings → Secrets and variables → Actions → New repository secret

Name:
FOOTBALLDATA_API_KEY

Value:
API anahtarınız

API anahtarını index.html içine koymayın.

## 3) Dosyalar
- index.html → GitHub Pages arayüzü
- fetch_bulletin.py → veri çekme/model
- .github/workflows/update-bulletin.yml → günlük otomatik çalışma
- data.json → otomatik üretilen bülten

## 4) İlk çalıştırma
GitHub → Actions → Daily football bulletin → Run workflow.

Başarılı çalışırsa data.json oluşur ve Pages'teki V4 bülteni güncellenir.

Not: API kapsamı ve bazı gelişmiş korner/prediction alanları sağlayıcının planına göre değişebilir.
